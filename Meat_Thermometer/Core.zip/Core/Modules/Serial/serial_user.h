// serial_user.h

#ifndef _SERIAL_USER_
#define _SERIAL_USER_

// prototypes

uint8_t ProcessReceiveBuffer(void);
uint8_t ProcessPacket(void);

#endif